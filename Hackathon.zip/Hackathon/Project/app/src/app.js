import React from 'react';
import './app.css';
import { Nav, NavItem } from 'react-bootstrap';

export default class App extends React.Component {
	render() {
		return(
			<div>
				<div className="header">
				<span className="headerTitle">Hackathon</span>
				</div>
				<div className="conatiner">
					<Nav bsStyle="tabs" activeKey="1">
				        <NavItem eventKey="1" href="/home"><span className="navName">Home</span></NavItem>                                      
				        <NavItem eventKey="2" title="Item"><span className="navName">Products</span></NavItem>
				        <NavItem eventKey="3"><span className="navName">About Us</span></NavItem>
				    </Nav>
			    </div>
			    <div>
			    	<input className="searchBox" type="text" name="search" placeholder="Search.."></input>
			    </div>
			</div>
			);
	}
}